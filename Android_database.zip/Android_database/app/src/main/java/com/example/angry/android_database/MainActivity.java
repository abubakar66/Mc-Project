package com.example.angry.android_database;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;


public class MainActivity extends ActionBarActivity {

    private EditText name;
    private EditText contact;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHandler db = new DatabaseHandler(this);
        //CRUD Operations

        name = (EditText)findViewById(R.id.Name_text);
        contact =(EditText)findViewById(R.id.contact_text);

        String _name = name.getText().toString();
        String _contact = contact.getText().toString();

        db.addContact(new Contact(_name,_contact));
        // Inserting Contacts
        //Log.d("Insert: ", "Inserting ..");
        //db.addContact(new Contact("ABC", "9100000000"));
        //db.addContact(new Contact("ABC1", "9199999999"));
        //db.addContact(new Contact("ABC2", "9522222222"));
        //db.addContact(new Contact("ABC3", "9533333333"));

        // Reading all contacts
//        Log.d("Reading: ", "Reading all contacts..");
//        List<Contact> contacts = db.getAllContacts();
//
//        for (Contact cn : contacts) {
//            String log = "Id: " + cn.getID()+ " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
//            // Writing Contacts to log
//            Log.d("Name: ", log);
//        }
    }

    public void showlist(View view)
    {
        Intent intent=new Intent(MainActivity.this,infolist.class);
        startActivity(intent);
    }
}