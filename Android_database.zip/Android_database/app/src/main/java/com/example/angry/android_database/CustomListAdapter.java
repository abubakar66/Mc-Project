package com.example.angry.android_database;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by angry on 5/6/2017.
 */


public class CustomListAdapter extends ArrayAdapter {

    Context context;
    ArrayList<Contact> lmt;
    String[] contact;
    String[] name;
    String[] url;
    TextView nm,cnt,id;

    public CustomListAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull ArrayList<Contact> lmt) {
        super(context, resource, lmt);
        this.context=context;
        this.lmt=lmt;
    }

    /*public CustomListAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull String[] name ,@NonNull String[] contact, String[] url) {
       // super(context, resource, objects);
        super(context,resource,name);
        this.context=context;
        this.contact=contact;
        this.name=name;
        this.url=url;
    }*/




    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view;
        if(convertView==null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.infolist, null, false);
            nm = (TextView) view.findViewById(R.id.name);
            cnt = (TextView) view.findViewById(R.id.contact);
            id = (TextView) view.findViewById(R.id.id);
        }
        else
        {
            view=convertView;
        }
        /*nm.setText(name[position]);
        cnt.setText(contact[position]);
        urltxt.setText(url[position]);*/
        nm.setText(lmt.get(position).getName());
        cnt.setText(lmt.get(position).getPhoneNumber());
        id.setText(lmt.get(position).getID());
        return view;
    }
}
