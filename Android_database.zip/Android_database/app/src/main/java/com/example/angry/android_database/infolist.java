package com.example.angry.android_database;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class infolist extends AppCompatActivity {


    ArrayList<Contact> lmt=new ArrayList<>();
    private ListView lstview;
    CustomListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.infolist);
        DatabaseHandler db = new DatabaseHandler(this);
        List<Contact> contacts = db.getAllContacts();
        for (Contact cn : contacts) {
            lmt.add(cn);
        }
        adapter=new CustomListAdapter(this,R.layout.infolist,lmt);
        lstview=(ListView)findViewById(R.id.mylist);
        lstview.setAdapter(adapter);
    }
    public void back(View view)
    {
        Intent intent=new Intent(infolist.this,MainActivity.class);
        startActivity(intent);
    }
}
